#!/bin/bash

echo -n "Type Your domain: "
read domain

nmap -v -A $domain -oN np.txt
nmap -sV $domain -oN np1.txt